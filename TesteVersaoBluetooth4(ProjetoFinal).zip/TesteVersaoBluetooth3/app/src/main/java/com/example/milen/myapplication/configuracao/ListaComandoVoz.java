package com.example.milen.myapplication.configuracao;

import android.content.ContentValues;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.milen.myapplication.R;
import com.example.milen.myapplication.banco_dados.ComandoVoz;
import com.example.milen.myapplication.banco_dados.ComandoVozDAO;
import com.example.milen.myapplication.banco_dados.CriarBancoComandoVoz;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class ListaComandoVoz extends AppCompatActivity {


    Button btnLookup;
    CheckBox comandoCheckBox;
    List<Item> items;
    ListView listView;
    ItemsListAdapter myItemsListAdapter;
    CriarBancoComandoVoz banco;
    ImageView imageView;
    ComandoVozDAO comandoVozDAO;
    ArrayList<ComandoVoz> comandovozes;
    SQLiteDatabase database;
    Cursor c;
    byte[] img,img1,img2;
    Bitmap b;

    public ListaComandoVoz() {
    }
    // Integer drawab;
    //List<ComandoVoz>comdVoz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.configuracao_lista_comandovoz);
        banco = new CriarBancoComandoVoz(getApplicationContext());
        comandoVozDAO = new ComandoVozDAO(banco.getWritableDatabase());

        listView = (ListView)findViewById(R.id.list_item);
        btnLookup = (Button)findViewById(R.id.botaoComandoVoz);
        comandoCheckBox = (CheckBox)findViewById(R.id.comandoCheckBox);
        imageView = (ImageView)findViewById(R.id.imageView);
        initItems();
        myItemsListAdapter = new ItemsListAdapter(this, items);
        listView.setAdapter(myItemsListAdapter);

        //for (int i = 0; i <= codImagem.size(); i++) {

            //}
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Toast.makeText(ListaComandoVoz.this,
                        ((Item)(parent.getItemAtPosition(position))).itemString,
                        Toast.LENGTH_LONG).show();
            }});

        btnLookup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str = "Item Selecionado:\n";

                for (int i = 0; i < items.size(); i++) {
                       //for (int j = 0; j < comandovozes.size(); j++) {
                    if (items.get(i).isChecked()) {
                        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.lampada);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                        byte[]img = stream.toByteArray();

                        database = banco.getWritableDatabase();

                        ContentValues cv=new ContentValues();

                        cv.put("IMAGERESOURCE", img);

                        database.insert("COMANDOVOZ", null, cv);

                        String selectQuery = "SELECT * FROM COMANDOVOZ";

                        c=database.rawQuery(selectQuery,null);



                        if(c!=null){

                            c.moveToFirst();

                            do{

                                img1=c.getBlob(c.getColumnIndex("IMAGERESOURCE"));

                            }while(c.moveToNext());

                        }

                       /* Bitmap b1=BitmapFactory.decodeByteArray(img1, 0, img1.length);

                        imageView.setImageBitmap(b1);*/

                        str += "Configuração salvo com sucesso" + "\n";
                        //Bitmap b1=BitmapFactory.decodeByteArray(img1, 0, img1.length);

                        comandoVozDAO.insereComandoVoz(new ComandoVoz(items.get(i).toString(), img,items.get(i).toString()));
                        //database.close();

                    }
                //}
            }
                Toast.makeText(ListaComandoVoz.this,str,
                        Toast.LENGTH_LONG).show();
                }
                /*
                int cnt = myItemsListAdapter.getCount();
                for (int i=0; i<cnt; i++){
                    if(myItemsListAdapter.isChecked(i)){
                        str += i + "\n";
                    }
                }
                */



           });
        }

//esta faltando adicionar o  codigo da imagem view para salvar a imagem no banco
    public void initItems() {
        String comandoR = "";
        String comandoG = "";
        String comandoB = "";
       // ImageView imageView;
        items = new ArrayList<Item>();

        //TypedArray arrayDrawable = getResources().obtainTypedArray(R.array.comandos);
        //TypedArray arrayText = getResources().obtainTypedArray(comandoVozDAO.consultaComandoVoz());
        TypedArray arrayText = getResources().obtainTypedArray(R.array.comandos);
        //ArrayList<ComandoVoz> comandovozes = new ArrayList<ComandoVoz>();


        for (int i = 0; i < arrayText.length(); i++) {
            //for (int j = 0; j < comandovozes.size(); j++) {
                //Drawable d = arrayDrawable.getDrawable(i);
                String s = arrayText.getString(i);
                boolean b = false;
                Item item = new Item(s, b);
                items.add(item);

                //ComandoVoz cm = new ComandoVoz(s,imageViewToByte(imageView));

            if (items.equals("r")) {
                    comandoR = "r";

                //comandovozes.add(draws,comandoR);
                //cm.getImageResource();
                    /*comandovozes.add(new ComandoVoz(comandoR,R.drawable.lampada,"lampada"));
                    imageView.setImageResource(comandovozes.get(j).getCaminhoImagem());*/



                   /* int drawab = getImageDrawableResId("lampada" + draws);
                    Drawable dr = getResources().getDrawable(drawab);
                    imageView.setImageDrawable(dr);*/


                //comdVoz.add();
                    /*imageArray = comandoVoz.getCaminhoImagem();
                    raw  = BitmapFactory.decodeByteArray(imageArray,0,imageArray.length);
                    imageView.setImageBitmap(raw);*/


                }
                if (items.equals("g")) {
                    comandoG = "g";
                    //ImageView imageView;
                    //ImageView vrImageView = (ImageView) findViewById(R.id.imageView);
                    //vrImageView.setImageDrawable(R.drawable.geladeira);
                    //comandoG.indexOf("g",R.drawable.geladeira);
                    //imageView.setImageResource(R.drawable.geladeira);
                     /*Drawable draws = getResources().getDrawable(R.drawable.geladeira);
                    imageView.setImageDrawable(draws);*/
                    /*comandovozes.add(new ComandoVoz(comandoG,R.drawable.porta,"porta"));
                    imageView.setImageResource(comandovozes.get(j).getCaminhoImagem());
                    /*Drawable draws = getResources().getDrawable(R.drawable.geladeira);
                    imageView.setImageDrawable(draws);


                    int drawab = getImageDrawableResId("geladeira" + draws);
                    Drawable dra = getResources().getDrawable(drawab);
                    imageView.setImageDrawable(dra);*/
                    /*imageArray = comandoVoz.getCaminhoImagem();
                    raw  = BitmapFactory.decodeByteArray(imageArray,0,imageArray.length);
                    imageView.setImageBitmap(raw);*/

                }
                if (items.equals("b")) {
                    comandoB = "b";
                    Drawable draws = getResources().getDrawable(R.drawable.geladeira);
                    imageView.setImageDrawable(draws);

                    /*comandovozes.add(new ComandoVoz(comandoB,R.drawable.ar_condicionado,"arcondicionado"));
                    imageView.setImageResource(comandovozes.get(j).getCaminhoImagem());*/

                    /*Drawable draws = getResources().getDrawable(R.drawable.porta);
                    imageView.setImageDrawable(draws);

                    int drawab = getImageDrawableResId("porta" + draws);
                    Drawable draw = getResources().getDrawable(drawab);
                    imageView.setImageDrawable(draw);*/
                    /*imageArray = comandoVoz.getCaminhoImagem();
                    raw  = BitmapFactory.decodeByteArray(imageArray,0,imageArray.length);
                    imageView.setImageBitmap(raw);*/


                }


            }

            //  for (int i = 0; i <= arrayText.length; i++) {
            // }


            arrayText.recycle();
          //  comandovozes.recycle();
            //comandoVozes.recycle();
        //}
    }

}


