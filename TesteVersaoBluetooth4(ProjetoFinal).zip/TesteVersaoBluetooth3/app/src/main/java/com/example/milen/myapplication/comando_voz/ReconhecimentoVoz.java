package com.example.milen.myapplication.comando_voz;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.TypedArray;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.milen.myapplication.banco_dados.ComandoVoz;
import com.example.milen.myapplication.banco_dados.ComandoVozBluetooth;
import com.example.milen.myapplication.banco_dados.ComandoVozDAO;
import com.example.milen.myapplication.bluetooth.BluetoothArduino;
import com.example.milen.myapplication.R;
import com.example.milen.myapplication.configuracao.Item;
import com.example.milen.myapplication.configuracao.ListaComandoVoz;

import java.util.ArrayList;

public  class ReconhecimentoVoz extends AppCompatActivity implements RecognitionListener {
    private static final int REQUEST_CODE = 1234;
    private static final int REQUEST_RECORD_PERMISSION = 100;
   // private ToggleButton toggleButton;
    private ProgressBar progressBar;
    public  ReconhecimentoVoz context;

    private SpeechRecognizer speech = null;
    private Intent recognizerIntent;
    public ImageView imageView;
    public static String MAC = "30:14:08:15:15:30";
    public boolean isChecked = true;
    public Button btnListaComandos,btnBotaoComando;
    BluetoothArduino bluetoothArduino = new BluetoothArduino();
    ListaComandoVoz listaComandoVoz = new ListaComandoVoz();
    ComandoVozDAO comVozDAO ;
    ComandoVozBluetooth comandoVozBluetooth = new ComandoVozBluetooth();
    ComandoVoz comandoVoz = new ComandoVoz();
    ArrayList<ComandoVoz> comandovozes = new ArrayList<ComandoVoz>();
    SQLiteDatabase database;
   // public int comandoVozAtual = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        imageView = (ImageView) findViewById(R.id.imageView);
        btnListaComandos = (Button)findViewById(R.id.btnListaComandos);
        btnBotaoComando = (Button)findViewById(R.id.btnBotaoComando);
        //
        //
        //String CaminhoDaFotas = comandoVoz.getCaminhoImagem();

        //imageView.setImageResource(CaminhoDaFotas);
        comVozDAO = new ComandoVozDAO(this);

        bluetoothArduino.definir_mac(MAC);
        speech = SpeechRecognizer.createSpeechRecognizer(this);
        speech.setRecognitionListener(this);
        recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,
                "br");
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);

        isChecked = true;
       /* String url_txt = "@drawable/porta";
        Bundle bundle = new Bundle();
        bundle.putString("url_txt", url_txt);*/

        progressBar.setIndeterminate(isChecked);
            ActivityCompat.requestPermissions
                    (ReconhecimentoVoz.this,
                            new String[]{Manifest.permission.RECORD_AUDIO},
                            REQUEST_RECORD_PERMISSION);
        btnListaComandos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //      setContentView(R.layout.lista_comandos) ;
                //ComandoVozTexto comandoVozTexto = new ComandoVozTexto();

                proximaTelaComandoVoz(view);


            }


        });
        btnBotaoComando.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //setContentView(R.layout.configuracao_lista_comandovoz);
                proximaTelaConfiguracao(v);

            }
        });

    }

    public void proximaTelaComandoVoz( View v){

        Intent intent = new Intent(this, ComandoVozTexto.class);
        startActivity(intent);
    }

    public void proximaTelaConfiguracao(View view){

        Intent intent = new Intent(this, ListaComandoVoz.class);
        startActivity(intent);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);



        switch (requestCode) {

            case REQUEST_RECORD_PERMISSION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    speech.startListening(recognizerIntent);
                } else {
                    Toast.makeText(ReconhecimentoVoz.this, "Permission Denied!", Toast
                            .LENGTH_SHORT).show();
                }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onStop() {
        super.onStop();
        if (speech != null) {
            speech.destroy();
        }
    }


    @Override
    public void onBeginningOfSpeech() {
        //O usuário começou a falar.

        progressBar.setVisibility(View.VISIBLE);
        Drawable drawable= getResources().getDrawable(R.drawable.images);
        imageView.setImageDrawable(drawable);

    }

    @Override
    public void onBufferReceived(byte[] buffer) {
        //mais som foi recebido

    }

    @Override
    public void onEndOfSpeech() {
        // chamando apos o usuario parar de falar.
        progressBar.setVisibility(View. INVISIBLE);
        Drawable drawable= getResources().getDrawable(R.drawable.images);
        imageView.setImageDrawable(drawable);

    }

    @Override
    public void onError(int errorCode) {
        //reservado para chamar eventos futuros
        Drawable drawable= getResources().getDrawable(R.drawable.images);
        imageView.setImageDrawable(drawable);
    }

    @Override
    public void onEvent(int arg0, Bundle arg1) {
        //reservado para chamar eventos futuros
    }

    @Override
    public void onPartialResults(Bundle arg0) {
        //chamado quando os resultados do comando de voz estao disponiveis
    }

    @Override
    public void onReadyForSpeech(Bundle arg0) {
        //chamando quando o ponteiro do terminal esta pronto para o usuario começar a falar
    }

    @Override
    public void onResults(Bundle results) {
        //chamado quando os resultados de pesquisas estao prontas
        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        //progressBar = new ArrayList<Item>();
//         listaComandoVoz.initItems();
        ArrayList<ComandoVoz> comandos = comVozDAO.consultaComandoVoz();
      //  database.close();

        //comVozDAO.insereComandoVoz(new ComandoVoz(comandoVoz.getNome(),imageView.getResources(),comandoVoz.getEnviarComando()));

        for (int i = 0; i < matches.size(); i++) {
            for (int j = 0; j < comandos.size(); j++) {
                //if (matches.get(i).equalsIgnoreCase("r")) {
                if (matches.get(i).equalsIgnoreCase(comandos.get(j).toString())) {
                    bluetoothArduino.conectar();
                    bluetoothArduino.enviar(comandos.get(j).toString());

                 //   bluetoothArduino.enviar(comandoVoz.getEnviarComando());
                    /*comandovozes.add(new ComandoVoz("r",R.drawable.lampada,"lampada"));
                    comandovozes.add(new ComandoVoz("g",R.drawable.porta,"porta"));
                    comandovozes.add(new ComandoVoz("b",R.drawable.ar_condicionado,"arcondicionado"));
                    imageView.setImageResource(comandovozes.get(j).getCaminhoImagem());*/

                    progressBar.setVisibility(View.INVISIBLE);
                    bluetoothArduino.desconectar();

                    //int CaminhoDaFot = comandoVoz.getCaminhoImagem();
                  /*  String CaminhoDaFoto = String.valueOf(comandoVoz.getCaminhoImagem());*/

                    //int CaminhoDaFotas = Integer.parseInt(CaminhoDaFoto);
                   // String CaminhoDaFoto = comandoVoz.getCaminhoImagem();


                    //int CaminhoDaFoto = Integer.parseInt(CaminhoDaFot);

                    /*int resourceId = imageView.getResources().getIdentifier(CaminhoDaFoto, null, context.getPackageName());
                    imageView.setImageResource(resourceId);*/


                /*progressBar.setVisibility(View.INVISIBLE);
                bluetoothArduino.desconectar();*/

                }
            /*if (matches.get(i).equalsIgnoreCase("g")) {

                bluetoothArduino.conectar();
                bluetoothArduino.enviar("g");
                Drawable drawable = getResources().getDrawable(R.drawable.porta);
                imageView.setImageDrawable(drawable);

                progressBar.setVisibility(View.INVISIBLE);
                bluetoothArduino.desconectar();

                //bluetoothArduino.desconectar();

                /*progressBar.setVisibility(View.INVISIBLE);
                bluetoothArduino.desconectar();*/
                //}
            /*if (matches.get(i).equalsIgnoreCase("b")) {

                bluetoothArduino.conectar();
                bluetoothArduino.enviar("b");
                Drawable drawable = getResources().getDrawable(R.drawable.ar_condicionado);
                imageView.setImageDrawable(drawable);

                progressBar.setVisibility(View.INVISIBLE);
                bluetoothArduino.desconectar();


                /*progressBar.setVisibility(View.INVISIBLE);
                bluetoothArduino.desconectar();*/


            /*}if(matches.get(i).equalsIgnoreCase("sair")){
                finish();
                System.exit(0);

                bluetoothArduino.desconectar();

            }
            }*/

                speech.startListening(recognizerIntent);
            }
        }
    }


    @Override
    public void onRmsChanged(float rmsdB) {
        //o nivel de som de fluxo de saida foi alterado
        progressBar.setVisibility(View.VISIBLE);
        /*Drawable drawable= getResources().getDrawable(R.drawable.barra_status_novo);
        imageView.setImageDrawable(drawable);*/
    }


    public static String getErrorText(int errorCode) {
        String message;
        switch (errorCode) {
            case SpeechRecognizer.ERROR_AUDIO:
                message = "Audio recording error";
                break;
            case SpeechRecognizer.ERROR_CLIENT:
                message = "Client side error";
                break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                message = "Insufficient permissions";
                break;
            case SpeechRecognizer.ERROR_NETWORK:
                message = "Network error";
                break;
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                message = "Network timeout";
                break;
            case SpeechRecognizer.ERROR_NO_MATCH:
                message = "No match";
                break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                message = "RecognitionService busy";
                break;
            case SpeechRecognizer.ERROR_SERVER:
                message = "error from server";
                break;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                message = "No speech input";
                break;
            default:
                message = "Didn't understand, please try again.";
                break;
        }
        return message;
    }

}