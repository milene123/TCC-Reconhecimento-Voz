package com.example.milen.myapplication.bluetooth;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ListActivity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

import static android.R.layout.*;
public class BluetoothArduino  {

    BluetoothAdapter meuBluetoothAdapter = null;
    BluetoothDevice meuDevice = null;
    BluetoothSocket meuSocket = null;
    boolean conexao = false;
   // ConnectedThread conneTread;
    public String MAC = "30:14:08:15:15:30";
    public  InputStream mmInStream;
    public  OutputStream mmOutStream;
    //ListaDispositivo listaDispositivo = new ListaDispositivo();
    UUID MEU_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

    /*public boolean conectar() {


        try {
            meuBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            meuDevice = meuBluetoothAdapter.getRemoteDevice(MAC);
            meuSocket = meuDevice.createRfcommSocketToServiceRecord(MEU_UUID);
            /*conneTread = new ConnectedThread(meuSocket);
            meuSocket.connect();
            conexao = true;
            conneTread.start();*/

        /*} catch (IOException erro) {
            conexao=false;
        }
        return conexao;
    }*/
        public boolean conectar() {

        try {

            meuBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            meuDevice = meuBluetoothAdapter.getRemoteDevice(MAC);
            meuSocket = meuDevice.createRfcommSocketToServiceRecord(MEU_UUID);
            InputStream tmpIn = null;
            OutputStream tmpOut = null;
            tmpIn = meuSocket.getInputStream();
            tmpOut = meuSocket.getOutputStream();

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
            /*conneTread = new ConnectedThread(meuSocket);
            meuSocket.connect();
            conexao = true;
            conneTread.start();*/

        } catch (IOException erro) {
            conexao=false;
        }
        return conexao;
    }
/*
    public ArrayList<BluetoothDevice> encontrarDispositivo() {
        Set<BluetoothDevice> pairedDevices = meuBluetoothAdapter.getBondedDevices();
        ArrayList<BluetoothDevice> deviceList = new ArrayList<>();

        // check has paired devices or not
        if (pairedDevices.size() > 0) {
            // initiate array list
            //deviceList = new ArrayList<>();

            // get names, address and its type
            for (BluetoothDevice device : pairedDevices) {
                //deviceList.add(device.getName() + "\n" + device.getAddress());
                deviceList.add(device);
            }
        }

        return deviceList;
    }
*/

    public void definir_mac(String MAC) {
        this.MAC = MAC;
    }

    public void enviar(String comando) {

        byte[] msgBuffer = comando.getBytes();
        try {

            meuSocket.connect();
            mmOutStream.write(msgBuffer);

            //meuSocket.mmOutStream.write(msgBuffer);
        } catch (IOException e) {

        }

    }
    public boolean conectado() {

        return conexao;
    }
    public boolean desconectar(){
        if (meuSocket.isConnected ()) {
            // desconectar
            try {
                meuSocket.close();


            } catch ( IOException e) {
                e.printStackTrace ();

            }
        }
        return false;
    }
}



    /*class ConnectedThread extends Thread {


        public final BluetoothSocket mmSocket;
        public final InputStream mmInStream;
        public final OutputStream mmOutStream;
        public Handler mHandler;
        private static final int MESSAGE_READ = 1;

        public ConnectedThread(BluetoothSocket socket) {
            mmSocket = socket;

            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            // Get the input and output streams, using temp objects because
            // member streams are final

            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) {

            }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

       /* public void run() {
            byte[] buffer = new byte[1024];  // buffer store for the stream
            int bytes; // bytes returned from read()

            // Keep listening to the InputStream until an exception occurs
            while (true) {
                try {
                    // Read from the InputStream
                    bytes = mmInStream.read(buffer);
                    // Send the obtained bytes to the UI activity
                    mHandler.obtainMessage(MESSAGE_READ, bytes, -1, buffer)
                            .sendToTarget();
                } catch (IOException e) {
                    break;
                }
            }*/

            /* Call this from the main activity to send data to the remote device */
        /*public void enviar(String dadosEnviar) {
            byte[] msgBuffer = dadosEnviar.getBytes();
            try {
                mmOutStream.write(msgBuffer);
            } catch (IOException e) {
            }
        }*/