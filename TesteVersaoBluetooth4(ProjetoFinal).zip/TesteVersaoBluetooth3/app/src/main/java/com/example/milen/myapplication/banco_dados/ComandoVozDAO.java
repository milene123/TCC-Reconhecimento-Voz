package com.example.milen.myapplication.banco_dados;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.provider.MediaStore;

import java.util.ArrayList;

public class ComandoVozDAO {
    SQLiteDatabase db;
    public ComandoVozDAO(){

    }
    public ComandoVozDAO(Context context){
        CriarBancoComandoVoz banco = new CriarBancoComandoVoz(context);
        db = banco.getWritableDatabase();
    }
    public ComandoVozDAO(SQLiteDatabase db){
        this.db=db;

    }

    public void criaTabelaComandoVoz(){
        String sql = "CREATE TABLE comandoVoz (" +
                "ID integer primary key autoincrement," +
                "NOME text," +
                "IMAGERESOURCE BLOB,"+
                "ENVIARCOMANDO TEXT"+
                ")";
        db.execSQL(sql);
    }

   /* public void criaTabelaComandoVozBluetooth(){
        String sql = "CREATE TABLE comandoVozBluetooth (" +
                "ID integer primary key autoincrement," +
                "ENVIARCOMANDO TEXT"+
                ")";
        db.execSQL(sql);
    }*/
    public void insereComandoVoz(ComandoVoz c){
        String sql = "INSERT INTO COMANDOVOZ (NOME,IMAGERESOURCE,ENVIARCOMANDO) VALUES ('" +
                c.getNome() +"','" +
                c.getImageResource()+"','"+
                c.getEnviarComando()+
                "')";
        System.out.println(sql);
        db.execSQL(sql);
    }
   /* public void insereComandoVozBluetooth(ComandoVozBluetooth c){
        String sql = "INSERT INTO COMANDOVOZBLUETOOTH (ENVIARCOMANDO) VALUES ('" +
                c.getEnviarComando()+
                "')";
        System.out.println(sql);
        db.execSQL(sql);
    }*/

   public ArrayList<ComandoVoz> consultaComandoVoz(){
        Cursor cursor;
        ArrayList<ComandoVoz> comandos = new ArrayList<ComandoVoz>();
                      cursor = db.query("comandovoz",
                new String[]{"ID","NOME"," IMAGERESOURCE","ENVIARCOMANDO"},
                null, null, null,null,null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    ComandoVoz cm = new ComandoVoz();
                    ComandoVozBluetooth cmBluetooth = new ComandoVozBluetooth();
                    cm.setId(cursor.getInt(cursor.getColumnIndex("ID")));
                    cm.setNome(cursor.getString(cursor.getColumnIndex("NOME")));
                    cm.setImageResource(cursor.getBlob(cursor.getColumnIndex("IMAGERESOURCE")));
                    cm.setEnviarComando(cursor.getString(cursor.getColumnIndex("ENVIARCOMANDO")));
                   // cm.setImageResource(cursor.getBlob(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)));

                    comandos.add(cm);
                } while (cursor.moveToNext());
            }
        }

        db.close();
        return comandos;
    }


}
