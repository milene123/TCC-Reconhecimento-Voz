package com.example.milen.myapplication.banco_dados;

public class ComandoVoz  {

    private int id;
    private String nome;
    //private int caminhoImagem;
    private byte[] imageResource;

    private String enviarComando;


    public ComandoVoz(){

    }
   /* public ComandoVoz(String nome) {
        this.nome=nome;

    }*/
    public ComandoVoz(String nome,byte[] imageResource,String enviarComando)
    {
        this.nome = nome;
        this.imageResource = imageResource;
        this.enviarComando = enviarComando;
    }

    //public ComandoVoz(int i, String s) {}

    public String getEnviarComando() {
        return enviarComando;
    }

    public void setEnviarComando(String enviarComando) {
        this.enviarComando = enviarComando;
    }
    public int getId() {
        return this.id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNome() {

        return this.nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public byte[] getImageResource() {
        return imageResource;
    }

    public void setImageResource(byte[] imageResource) {
        this.imageResource = imageResource;
    }


    // public int getImageResource() {
     //   return imageResource;
    //}

    //public void setImageResource(int imageResource) {
      //  this.imageResource = imageResource;
    //}

    @Override
    public String toString() {
        return  nome+" "+enviarComando;
    }
}
