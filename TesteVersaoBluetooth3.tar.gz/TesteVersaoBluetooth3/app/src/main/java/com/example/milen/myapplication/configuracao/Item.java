package com.example.milen.myapplication.configuracao;

public class Item {
    boolean checked;
    //Drawable ItemDrawable;
    String itemString;
    Item( String t, boolean b){
      //  ItemDrawable = drawable;
        itemString = t;
        checked = b;
    }

    public boolean isChecked(){
        return checked;
    }
    public String toString() {
        return itemString;
    }
}
