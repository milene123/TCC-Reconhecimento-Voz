package com.example.milen.myapplication.banco_dados;

public class ComandoVozBluetooth {


    private int id;
    private String enviarComando;
    public ComandoVozBluetooth(){

    }
    public ComandoVozBluetooth(String enviarComando) {
        this.enviarComando = enviarComando;
    }
    public int getId() {
        return this.id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getEnviarComando() {
        return enviarComando;
    }
    public void setEnviarComando(String enviarComando) {
        this.enviarComando = enviarComando;
    }

    public String toString() {
        return  enviarComando ;
    }



}
