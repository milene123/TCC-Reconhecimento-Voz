package com.example.milen.myapplication.banco_dados;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class CriarBancoComandoVoz extends SQLiteOpenHelper {
    public CriarBancoComandoVoz(Context context){

        super(context,"bancoComandoVoz.db",null,6);
    }
    public void onCreate(SQLiteDatabase sqLiteDatabase){
        ComandoVozDAO comandoVozDAO = new ComandoVozDAO(sqLiteDatabase);
        comandoVozDAO.criaTabelaComandoVoz();
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS comandoVoz");
        onCreate(sqLiteDatabase);
    }

}
