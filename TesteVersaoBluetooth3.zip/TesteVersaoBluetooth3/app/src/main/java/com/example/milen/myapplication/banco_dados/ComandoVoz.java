package com.example.milen.myapplication.banco_dados;

public class ComandoVoz  {

   // private int imageResource;
    private int id;
    private String nome;
    private String enviarComando;
    private String receberComando;
    private String imagemComando;
    private int caminhoImagem;

    public ComandoVoz(){

    }
    public ComandoVoz(String nome) {
        this.nome=nome;

    }
    public ComandoVoz(Integer caminhoImagem,String imagemComando)
    {
        this.imagemComando=imagemComando;
        this.caminhoImagem = caminhoImagem;
    }

    //public ComandoVoz(int i, String s) {}
    public String getEnviarComando() {
        return enviarComando;
    }

    public void setEnviarComando(String enviarComando) {
        this.enviarComando = enviarComando;
    }

    public String getReceberComando() {
        return receberComando;
    }

    public void setReceberComando(String receberComando) {
        this.receberComando = receberComando;
    }
    public int getId() {
        return this.id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNome() {
        return this.nome;
    }
    public String getImagemComando() {
        return imagemComando;
    }

    public void setImagemComando(String imagemComando) {
        this.imagemComando = imagemComando;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCaminhoImagem() {
        return caminhoImagem;
    }

    public void setCaminhoImagem(int caminhoImagem) {
        this.caminhoImagem = caminhoImagem;
    }

   // public int getImageResource() {
     //   return imageResource;
    //}

    //public void setImageResource(int imageResource) {
      //  this.imageResource = imageResource;
    //}

    @Override
    public String toString() {
        return  nome ;
    }
}
