package com.example.milen.myapplication.banco_dados;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.provider.MediaStore;

import java.util.ArrayList;

public class ComandoVozDAO {
    SQLiteDatabase db;
    public ComandoVozDAO(){

    }
    public ComandoVozDAO(Context context){
        CriarBancoComandoVoz banco = new CriarBancoComandoVoz(context);
        db = banco.getWritableDatabase();
    }
    public ComandoVozDAO(SQLiteDatabase db){
        this.db=db;

    }

    public void criaTabelaComandoVoz(){
        String sql = "CREATE TABLE comandoVoz (" +
                "ID integer primary key autoincrement," +
                "NOME text," +
                "ENVIARCOMANDO TEXT," +
                "RECEBERCOMANDO TEXT," +
                "IMAGEMCOMANDO"+
                ")";
        db.execSQL(sql);
    }

    public void insereComandoVoz(ComandoVoz c){
        String sql = "INSERT INTO COMANDOVOZ (NOME,ENVIARCOMANDO,RECEBERCOMANDO,IMAGEMCOMANDO) VALUES ('" +
                c.getNome() +"','" +
                c.getEnviarComando()+"','"+
                c.getReceberComando()+"','"+
                c.getImagemComando()+
                "')";
        System.out.println(sql);
        db.execSQL(sql);
    }

    /*public void atualizaLivro(Livro l){
        String sql = "UPDATE LIVRO SET " +
                "TITULO = '" + l.getTitulo() + "', " +
                "AUTOR = '" + l.getAutor() + "' " +
                "TEMA = '" + l.getTema() + "' " +
                "PAGINAATUAL = '" + l.getPagina_atual() + "' " +
                "DATALIDA = '" + l.getData_lida() + "' " +
                "WHERE ID = " + l.getId();
        db.execSQL(sql);
    }*/

    /*public void excluirLivro(Livro l){
        String sql = "DELETE FROM CONTATO WHERE ID = " + l.getId();
        db.execSQL(sql);
    }*/

   public ArrayList<ComandoVoz> consultaComandoVoz(){
        Cursor cursor;
        ArrayList<ComandoVoz> comandos = new ArrayList<ComandoVoz>();
        cursor = db.query("comandovoz",
                new String[]{"ID","NOME","ENVIARCOMANDO","RECEBERCOMANDO","IMAGEMCOMANDO"},
                null, null, null,null,null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    ComandoVoz cm = new ComandoVoz();
                    cm.setId(cursor.getInt(cursor.getColumnIndex("ID")));
                    cm.setNome(cursor.getString(cursor.getColumnIndex("NOME")));
                    cm.setEnviarComando(cursor.getString(cursor.getColumnIndex("ENVIARCOMANDO")));
                    cm.setReceberComando(cursor.getString(cursor.getColumnIndex("RECEBERCOMANDO")));
                    //cm.setCaminhoImagem(cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)));
                    cm.setCaminhoImagem(cursor.getInt(cursor.getColumnIndexOrThrow("IMAGEMCOMANDO")));
                    comandos.add(cm);
                } while (cursor.moveToNext());
            }
        }

        return comandos;
    }

}
