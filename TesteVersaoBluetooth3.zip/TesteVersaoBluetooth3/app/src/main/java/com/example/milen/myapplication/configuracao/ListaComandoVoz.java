package com.example.milen.myapplication.configuracao;

import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.milen.myapplication.R;
import com.example.milen.myapplication.banco_dados.ComandoVoz;
import com.example.milen.myapplication.banco_dados.ComandoVozDAO;
import com.example.milen.myapplication.banco_dados.CriarBancoComandoVoz;

import java.util.ArrayList;
import java.util.List;

public class ListaComandoVoz extends AppCompatActivity {


    Button btnLookup;
    CheckBox comandoCheckBox;
    List<Item> items;
    ListView listView;
    ItemsListAdapter myItemsListAdapter;
    CriarBancoComandoVoz banco;
    public ImageView imageView;
    ComandoVozDAO comandoVozDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.configuracao_lista_comandovoz);
        banco = new CriarBancoComandoVoz(this);
        comandoVozDAO = new ComandoVozDAO(banco.getWritableDatabase());

        listView = (ListView)findViewById(R.id.list_item);
        btnLookup = (Button)findViewById(R.id.botaoComandoVoz);
        comandoCheckBox = (CheckBox)findViewById(R.id.comandoCheckBox);
        initItems();
        myItemsListAdapter = new ItemsListAdapter(this, items);
        listView.setAdapter(myItemsListAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Toast.makeText(ListaComandoVoz.this,
                        ((Item)(parent.getItemAtPosition(position))).itemString,
                        Toast.LENGTH_LONG).show();
            }});

        btnLookup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str = "Item Selecionado:\n";

                for (int i=0; i<items.size(); i++)
                    if (items.get(i).isChecked()) {
                        str += i + "\n";
                        comandoVozDAO.insereComandoVoz(new ComandoVoz(items.get(i).toString()));
                    }

                /*
                int cnt = myItemsListAdapter.getCount();
                for (int i=0; i<cnt; i++){
                    if(myItemsListAdapter.isChecked(i)){
                        str += i + "\n";
                    }
                }
                */

                Toast.makeText(ListaComandoVoz.this,
                        str,
                        Toast.LENGTH_LONG).show();

            }
        });
    }

    public void initItems(){
        String comandoR = "";
        String comandoG = "";
        String comandoB = "";
        items = new ArrayList<Item>();

        //TypedArray arrayDrawable = getResources().obtainTypedArray(R.array.comandos);
        //TypedArray arrayText = getResources().obtainTypedArray(comandoVozDAO.consultaComandoVoz());
        TypedArray arrayText = getResources().obtainTypedArray(R.array.comandos);
        for(int i=0; i<arrayText.length(); i++){
            //Drawable d = arrayDrawable.getDrawable(i);
            String s = arrayText.getString(i);
            boolean b = false;
            Item item = new Item( s, b);
            items.add(item);
            if(items.equals("r")){
                comandoR = "r";
                Drawable drawable = getResources().getDrawable(R.drawable.lampada);
                imageView.setImageDrawable(drawable);
            }if(items.equals("g")){
                comandoG = "g";
                Drawable drawable = getResources().getDrawable(R.drawable.geladeira);
                imageView.setImageDrawable(drawable);
            }if(items.equals("b")){
                comandoB = "b";
                Drawable drawable = getResources().getDrawable(R.drawable.porta);
                imageView.setImageDrawable(drawable);
            }
        }

        arrayText.recycle();
    }

}


