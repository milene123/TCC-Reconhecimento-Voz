package com.example.milen.myapplication.comando_voz;

import android.annotation.TargetApi;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;

import com.example.milen.myapplication.R;

import java.util.Locale;

public class ComandoVozTexto extends AppCompatActivity implements TextToSpeech.OnInitListener {

    private TextToSpeech ttx;
    private EditText edit;
    private Button btn;


    @RequiresApi(api = Build.VERSION_CODES.DONUT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lista_comandos);

        ttx = new TextToSpeech(this, this);
        edit = (EditText) findViewById(R.id.editComando);
        btn = (Button) findViewById(R.id.btnGravar);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                speakOut();


            }


        });
    }

    @RequiresApi(api = Build.VERSION_CODES.DONUT)
    @Override
    public void onInit(int status) {

        if (status == TextToSpeech.SUCCESS) {
            int resutado = ttx.setLanguage(Locale.getDefault());
            if (resutado == TextToSpeech.LANG_NOT_SUPPORTED || resutado == TextToSpeech.LANG_MISSING_DATA) {
                Log.e("FTS", "Esta lingua não suporta");
            } else {
                btn.setEnabled(true);
                speakOut();
            }
        } else {
            Log.e("FTS", "Inicialização da linguagem");

        }
    }


    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @RequiresApi(api = Build.VERSION_CODES.DONUT)
    private void speakOut() {
        String text = edit.getText().toString();
        if (text.equals("abrir/fechar porta")) {
            ttx.speak(text, TextToSpeech.QUEUE_FLUSH, null);
            setContentView(R.layout.porta);
            //tela_porta();
        } else if (text.equals("ligar/desligar lâmpada")) {
            ttx.speak(text, TextToSpeech.QUEUE_FLUSH, null);
            setContentView(R.layout.lampada);
            //tela_lampada();
        } else if (text.equals("ligar/desligar ar condicionado")) {
            ttx.speak(text, TextToSpeech.QUEUE_FLUSH, null);
            setContentView(R.layout.ar_condicionado);
        } else if (text.equals("ligar/desligar geladeira")) {
            ttx.speak(text, TextToSpeech.QUEUE_FLUSH, null);
            setContentView(R.layout.geladeira);
            //tela_lampada();
        }
        //tela_lampada();
    }
}
   /*public void tela_lampada() {
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setContentView(R.layout.activity_main);
            }
        });

    }
    public void tela_porta() {
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setContentView(R.layout.activity_main);
            }
        });

    }*/





